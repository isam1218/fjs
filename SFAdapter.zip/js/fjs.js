var fjs = {
    config:{}
    , fdp: {}
    , app: {}
    , model: {}
    , controllers: {}
};