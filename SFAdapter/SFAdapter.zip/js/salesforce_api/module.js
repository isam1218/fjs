var sfa_model = angular.module('SF_API', []);

sfa_model.service('SFApi', fjs.sf.SFApiProviderFactory);