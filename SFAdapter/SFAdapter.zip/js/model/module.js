var sfa_model = angular.module('SFA_model', ['SF_API']);

sfa_model.service('DataManager', ['SFApi', fjs.model.DataManager]);

